import os
import random
from pathlib import Path
from typing import Tuple, List

import torch
import torchaudio
import math
from torch.utils.data import Dataset


class NoisyCleanDataset(Dataset):
    """Dataset for mixing clean speech with noise on the fly."""
    
    def __init__(
        self,
        clean_dir: str,
        noise_dir: str,
        sample_rate: int = 48000,
        duration: float = 3.0,
        snr_range: Tuple[float, float] = (-5.0, 20.0),
        seed: int = 42,
    ):
        self.clean_files = self._get_audio_files(clean_dir)
        self.noise_files = self._get_audio_files(noise_dir)
        self.sample_rate = sample_rate
        self.target_samples = int(sample_rate * duration)
        self.snr_range = snr_range
        self.rng = random.Random(seed)

    def _get_audio_files(self, directory: str) -> List[Path]:
        path = Path(directory)
        if not path.exists():
            return []
        # Find all common audio files
        exts = ('.wav', '.flac', '.mp3', '.ogg')
        files = [p for p in path.rglob('*') if p.suffix.lower() in exts]
        return sorted(files)

    def __len__(self) -> int:
        return len(self.clean_files)

    def _load_and_pad_crop(self, file_path: Path) -> torch.Tensor:
        try:
            audio, sr = torchaudio.load(file_path)
            # Resample if needed
            if sr != self.sample_rate:
                resampler = torchaudio.transforms.Resample(orig_freq=sr, new_freq=self.sample_rate)
                audio = resampler(audio)
            
            # Convert to mono
            if audio.shape[0] > 1:
                audio = audio.mean(dim=0, keepdim=True)
                
            # Pad or crop
            if audio.shape[1] < self.target_samples:
                pad_size = self.target_samples - audio.shape[1]
                audio = torch.nn.functional.pad(audio, (0, pad_size))
            elif audio.shape[1] > self.target_samples:
                start = self.rng.randint(0, audio.shape[1] - self.target_samples)
                audio = audio[:, start:start + self.target_samples]
                
            return audio
        except Exception:
            # Return silence if loading fails
            return torch.zeros(1, self.target_samples)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        clean_path = self.clean_files[idx]
        noise_path = self.rng.choice(self.noise_files) if self.noise_files else None
        
        clean_audio = self._load_and_pad_crop(clean_path)
        
        if noise_path is None:
            return clean_audio, clean_audio
            
        noise_audio = self._load_and_pad_crop(noise_path)
        
        # Mix clean and noise
        clean_rms = torch.sqrt(torch.mean(clean_audio ** 2) + 1e-8)
        noise_rms = torch.sqrt(torch.mean(noise_audio ** 2) + 1e-8)
        
        snr = self.rng.uniform(*self.snr_range)
        snr_linear = 10 ** (snr / 20)
        
        noise_scaler = clean_rms / (noise_rms * snr_linear)
        noisy_audio = clean_audio + noise_audio * noise_scaler
        
        # Normalize to prevent clipping
        max_val = torch.max(torch.abs(noisy_audio))
        if max_val > 0.99:
            noisy_audio = noisy_audio * (0.99 / max_val)
            clean_audio = clean_audio * (0.99 / max_val)
            
        return noisy_audio, clean_audio


class ValidationDataset(Dataset):
    """Validation dataset with paired clean and noisy files (e.g., VoiceBank-DEMAND)."""
    
    def __init__(
        self,
        clean_dir: str,
        noisy_dir: str,
        sample_rate: int = 48000,
        duration: float = 3.0,
    ):
        self.clean_dir = Path(clean_dir)
        self.noisy_dir = Path(noisy_dir)
        self.sample_rate = sample_rate
        self.target_samples = int(sample_rate * duration)
        
        # Assumes filenames match exactly between clean and noisy dirs
        if self.clean_dir.exists():
            self.file_names = sorted([f.name for f in self.clean_dir.glob('*.wav')])
        else:
            self.file_names = []

    def __len__(self) -> int:
        return len(self.file_names)

    def _load_and_process(self, file_path: Path) -> torch.Tensor:
        try:
            audio, sr = torchaudio.load(file_path)
            if sr != self.sample_rate:
                resampler = torchaudio.transforms.Resample(orig_freq=sr, new_freq=self.sample_rate)
                audio = resampler(audio)
            
            if audio.shape[0] > 1:
                audio = audio.mean(dim=0, keepdim=True)
                
            if audio.shape[1] < self.target_samples:
                pad_size = self.target_samples - audio.shape[1]
                audio = torch.nn.functional.pad(audio, (0, pad_size))
            elif audio.shape[1] > self.target_samples:
                audio = audio[:, :self.target_samples]
                
            return audio
        except Exception:
            return torch.zeros(1, self.target_samples)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        file_name = self.file_names[idx]
        clean_path = self.clean_dir / file_name
        noisy_path = self.noisy_dir / file_name
        
        clean_audio = self._load_and_process(clean_path)
        noisy_audio = self._load_and_process(noisy_path)
        
        return noisy_audio, clean_audio
